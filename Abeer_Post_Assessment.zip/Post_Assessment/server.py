import pickle
import streamlit as st


# loading the saved models

loan_model = pickle.load(open('loan_prediction_model.pkl', 'rb'))
def predict(Gender,Married,Dependents,Education,Self_Employed,
            ApplicantIncome,CoapplicantIncome,Loan_Amount,
            Loan_Amount_Term,Credit_History,Property_Area):
    prediction=loan_model.predict([[Gender,Married,Dependents,Education,Self_Employed,
                                    ApplicantIncome,CoapplicantIncome,Loan_Amount,
                                    Loan_Amount_Term,Credit_History,Property_Area]])
    return prediction
def preprocess_input(Gender, Married, Dependents, Education, Self_Employed, ApplicantIncome, 
                     CoapplicantIncome, Loan_Amount, Loan_Amount_Term, Credit_History, Property_Area):
    # Convert categorical variables to numerical values (dummy variables)
    gender = 1 if Gender == 'Male' else 0
    married = 1 if Married == 'Yes' else 0
    education = 1 if Education == 'Graduate' else 0
    self_employed = 1 if Self_Employed == 'Yes' else 0

    # Return preprocessed input as a list
    return [gender, married, int(Dependents), education, self_employed, float(ApplicantIncome), 
            float(CoapplicantIncome), float(Loan_Amount), float(Loan_Amount_Term), 
            float(Credit_History), Property_Area]

def main():
    st.title("Loan Prediction")
    html_temp = """
    <div style="background-color:tomato;padding:10px">
    <h2 style="color:white;text-align:center;">Loan Predictor by Abeer</h2>   
    </div>
    """
    st.markdown(html_temp,unsafe_allow_html=True)

    # Input fields including Loan ID
    Gender = st.selectbox("Gender", ["Male", "Female"])
    Married = st.selectbox("Married", ["Yes", "No"])
    Dependents = st.number_input("Dependents", min_value=0)
    Education = st.selectbox("Education", ["Graduate", "Not Graduate"])
    Self_Employed = st.selectbox("Self Employed", ["Yes", "No"])
    ApplicantIncome = st.number_input("Applicant Income", min_value=0)
    CoapplicantIncome = st.number_input("Coapplicant Income", min_value=0)
    Loan_Amount = st.number_input("Loan Amount", min_value=0)
    Loan_Amount_Term = st.number_input("Loan Amount Term", min_value=0)
    Credit_History = st.number_input("Credit History", min_value=0)
    Property_Area = st.number_input("Property Area", min_value = 0)

    result = ""
    if st.button("Predict"):
        processed_input = preprocess_input(Gender, Married, Dependents, Education, Self_Employed, 
                                           ApplicantIncome, CoapplicantIncome, Loan_Amount, 
                                           Loan_Amount_Term, Credit_History, Property_Area)
        result = predict(*processed_input)
    st.success('The output is {}'.format(result))
    if st.button("About"):
        st.text("Lets LEarn")
        st.text("Built with Streamlit")
main()

